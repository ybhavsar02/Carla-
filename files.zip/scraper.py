"""
Shri Sairam Bus Fare Tracker - Scraper
Targets: shrisairambus.com (ASP.NET, plain GET requests, no auth needed)
Stores price snapshots to SQLite every run (schedule via cron)
"""

import requests
from bs4 import BeautifulSoup
import sqlite3
import json
import time
import random
import logging
from datetime import datetime
from pathlib import Path

# ─── Config ────────────────────────────────────────────────────────────────────
DB_PATH = Path(__file__).parent.parent / "data" / "fares.db"
BASE_URL = "https://shrisairambus.com"

# All known routes from the site (From → To)
ROUTES = [
    ("Pune", "Mumbai"),
    ("Mumbai", "Pune"),
    ("Pune", "Jalgaon"),
    ("Jalgaon", "Pune"),
    ("Pune", "Malkapur"),
    ("Pune", "Aurangabad"),
    ("Aurangabad", "Pune"),
    ("Pune", "Nashik"),
    ("Jalgaon", "Mumbai"),
    ("Mumbai", "Jalgaon"),
    ("Pune", "Dhulia"),
    ("Dhulia", "Pune"),
    ("Pune", "Solapur"),
    ("Solapur", "Pune"),
    ("Pune", "Ahmednagar"),
]

# Polite headers — looks like a real Chrome browser from India
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-IN,en;q=0.9,hi;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Referer": "https://shrisairambus.com/",
}

# ─── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / "data" / "scraper.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

# ─── Database ──────────────────────────────────────────────────────────────────
def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS price_snapshots (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            from_city   TEXT NOT NULL,
            to_city     TEXT NOT NULL,
            bus_name    TEXT,
            bus_type    TEXT,
            departure   TEXT,
            arrival     TEXT,
            seat_type   TEXT,
            price       REAL,
            seats_avail INTEGER,
            journey_date TEXT,
            scraped_at  TEXT NOT NULL
        )
    """)
    c.execute("""
        CREATE INDEX IF NOT EXISTS idx_route_date
        ON price_snapshots(from_city, to_city, journey_date, scraped_at)
    """)
    conn.commit()
    conn.close()
    log.info(f"DB ready at {DB_PATH}")


def save_snapshot(records: list[dict]):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    for r in records:
        c.execute("""
            INSERT INTO price_snapshots
            (from_city, to_city, bus_name, bus_type, departure, arrival,
             seat_type, price, seats_avail, journey_date, scraped_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (
            r["from_city"], r["to_city"], r.get("bus_name"), r.get("bus_type"),
            r.get("departure"), r.get("arrival"), r.get("seat_type"),
            r.get("price"), r.get("seats_avail"), r.get("journey_date"),
            r["scraped_at"]
        ))
    conn.commit()
    conn.close()
    log.info(f"Saved {len(records)} records to DB")


# ─── Scraper ───────────────────────────────────────────────────────────────────
def get_search_page(from_city: str, to_city: str, journey_date: str) -> str | None:
    """
    Hit the FindRoute.aspx page — plain GET, no JS needed.
    URL pattern discovered via DevTools XHR inspection.
    """
    url = f"{BASE_URL}/FindRoute.aspx"
    params = {
        "From": from_city,
        "To": to_city,
        "Date": journey_date,   # format: dd-MM-yyyy
    }
    try:
        resp = requests.get(url, params=params, headers=HEADERS, timeout=15)
        resp.raise_for_status()
        return resp.text
    except requests.RequestException as e:
        log.error(f"Request failed for {from_city}→{to_city}: {e}")
        return None


def parse_fare_page(html: str, from_city: str, to_city: str, journey_date: str) -> list[dict]:
    """
    Parse the HTML response for bus listings.
    shrisairambus.com uses ASP.NET WebForms — fare data is in HTML tables.
    Adjust selectors after first real run based on actual HTML structure.
    """
    soup = BeautifulSoup(html, "html.parser")
    records = []
    scraped_at = datetime.now().isoformat()

    # ── Strategy 1: Look for standard bus result rows ──────────────────────────
    # These are common class names used by Mantis Technologies booking platform
    bus_rows = (
        soup.select(".bus-item") or
        soup.select(".busrow") or
        soup.select("tr.bus-detail") or
        soup.select(".travel-row") or
        soup.select("[class*='bus']")
    )

    if bus_rows:
        for row in bus_rows:
            try:
                record = {
                    "from_city": from_city,
                    "to_city": to_city,
                    "journey_date": journey_date,
                    "scraped_at": scraped_at,
                    "bus_name": _text(row, ".bus-name, .operator-name, .company-name"),
                    "bus_type": _text(row, ".bus-type, .service-type, .type"),
                    "departure": _text(row, ".dep-time, .departure, .time-dep"),
                    "arrival": _text(row, ".arr-time, .arrival, .time-arr"),
                    "price": _price(row, ".fare, .price, .amount, .seat-fare"),
                    "seats_avail": _num(row, ".seats, .available, .avail-seats"),
                    "seat_type": _text(row, ".seat-type, .berth-type"),
                }
                if record["price"]:  # only save if price found
                    records.append(record)
            except Exception as e:
                log.warning(f"Row parse error: {e}")

    # ── Strategy 2: Fallback — scan all tables ─────────────────────────────────
    if not records:
        log.info(f"No .bus-item found for {from_city}→{to_city}, trying table scan...")
        tables = soup.find_all("table")
        for table in tables:
            rows = table.find_all("tr")
            for row in rows:
                cells = [td.get_text(strip=True) for td in row.find_all(["td", "th"])]
                if len(cells) >= 3:
                    # Look for price patterns like ₹450, Rs.450, 450.00
                    price = None
                    for cell in cells:
                        cleaned = cell.replace("₹", "").replace("Rs.", "").replace(",", "").strip()
                        try:
                            val = float(cleaned)
                            if 50 < val < 5000:  # sane fare range
                                price = val
                                break
                        except ValueError:
                            continue
                    if price:
                        records.append({
                            "from_city": from_city,
                            "to_city": to_city,
                            "journey_date": journey_date,
                            "scraped_at": scraped_at,
                            "bus_name": cells[0] if cells else None,
                            "bus_type": None,
                            "departure": cells[1] if len(cells) > 1 else None,
                            "arrival": cells[2] if len(cells) > 2 else None,
                            "price": price,
                            "seats_avail": None,
                            "seat_type": None,
                        })

    # ── Strategy 3: Save raw HTML for manual inspection ────────────────────────
    if not records:
        raw_path = Path(__file__).parent.parent / "data" / f"raw_{from_city}_{to_city}_{journey_date}.html"
        raw_path.write_text(html, encoding="utf-8")
        log.warning(f"No data parsed. Raw HTML saved to {raw_path} — inspect & adjust selectors.")

    log.info(f"{from_city}→{to_city}: found {len(records)} fare records")
    return records


# ─── Helper parsers ────────────────────────────────────────────────────────────
def _text(tag, selectors: str) -> str | None:
    for sel in selectors.split(","):
        el = tag.select_one(sel.strip())
        if el:
            return el.get_text(strip=True)
    return None

def _price(tag, selectors: str) -> float | None:
    raw = _text(tag, selectors)
    if raw:
        cleaned = raw.replace("₹", "").replace("Rs.", "").replace(",", "").strip()
        try:
            return float(cleaned.split()[0])
        except (ValueError, IndexError):
            pass
    return None

def _num(tag, selectors: str) -> int | None:
    raw = _text(tag, selectors)
    if raw:
        try:
            return int(''.join(filter(str.isdigit, raw)))
        except ValueError:
            pass
    return None


# ─── Main runner ───────────────────────────────────────────────────────────────
def run_scrape(routes=None, days_ahead=1):
    """
    Scrape fares for given routes.
    days_ahead: how many future dates to check (1 = today+1, useful for tomorrow's prices)
    """
    init_db()
    if routes is None:
        routes = ROUTES

    from datetime import timedelta
    dates = [
        (datetime.now() + timedelta(days=i)).strftime("%d-%m-%Y")
        for i in range(1, days_ahead + 1)
    ]

    all_records = []

    for (from_city, to_city) in routes:
        for jdate in dates:
            log.info(f"Scraping {from_city} → {to_city} | {jdate}")
            html = get_search_page(from_city, to_city, jdate)
            if html:
                records = parse_fare_page(html, from_city, to_city, jdate)
                all_records.extend(records)

            # Polite delay: 8–15 seconds between requests
            delay = random.uniform(8, 15)
            log.info(f"Waiting {delay:.1f}s...")
            time.sleep(delay)

    if all_records:
        save_snapshot(all_records)
        log.info(f"✅ Total records saved: {len(all_records)}")
    else:
        log.warning("⚠️  No records scraped. Check raw HTML files in /data/ folder.")

    return all_records


if __name__ == "__main__":
    # Run for top 5 routes, 2 days ahead
    run_scrape(
        routes=ROUTES[:5],
        days_ahead=2
    )
